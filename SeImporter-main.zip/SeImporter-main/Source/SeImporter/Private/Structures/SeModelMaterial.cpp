﻿#include "Structures/SeModelMaterial.h"

FSeModelMaterial::FSeModelMaterial()
{
	Header = new FSeModelMaterialHeader();
}
