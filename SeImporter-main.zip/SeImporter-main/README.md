# SeImporter
 Based on https://github.com/djhaled/Unreal-SeTools
 Only the basic import animation function is available